﻿namespace Covid
{
    partial class MainForm
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.fElipse = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.dControl = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.impostor = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkDoorCooldown = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkKillImpostor = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkInfiniteSabotage = new Bunifu.Framework.UI.BunifuCheckbox();
            this.chkIgnoreWalls = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkTaskImpostor = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkInfiniteRange = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkKillCooldown = new Bunifu.Framework.UI.BunifuCheckbox();
            this.chkImpostor = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tHint = new System.Windows.Forms.ToolTip(this.components);
            this.bunifuImageButton7 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.speedSlider = new Bunifu.Framework.UI.BunifuSlider();
            this.cForm = new System.Windows.Forms.Timer(this.components);
            this.oForm = new System.Windows.Forms.Timer(this.components);
            this.dControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.vision = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel25 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkSeeGhostsChat = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkSeeGhosts = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkSuperVision = new Bunifu.Framework.UI.BunifuCheckbox();
            this.chkSeeImpostor = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.miscellaneous = new System.Windows.Forms.TabPage();
            this.bunifuCustomLabel28 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkSkipAll = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel27 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkNukeRoom = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel26 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel24 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkInfiniteKickVote = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkBypassBanRooms = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkUnlockItems = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel19 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkWallhack = new Bunifu.Framework.UI.BunifuCheckbox();
            this.chkRemoveBanTime = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel20 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkDoubleHost = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel21 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkFastChat = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel22 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel23 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkLagSwitch = new Bunifu.Framework.UI.BunifuCheckbox();
            this.chkKickAll = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.Injection = new System.ComponentModel.BackgroundWorker();
            this.Votes = new System.ComponentModel.BackgroundWorker();
            this.notifControl1 = new Covid.NotifControl();
            this.InstaKillAll = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.chkInstaKillAll = new Bunifu.Framework.UI.BunifuCheckbox();
            this.impostor.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.vision.SuspendLayout();
            this.miscellaneous.SuspendLayout();
            this.SuspendLayout();
            // 
            // fElipse
            // 
            this.fElipse.ElipseRadius = 11;
            this.fElipse.TargetControl = this;
            // 
            // dControl
            // 
            this.dControl.Fixed = true;
            this.dControl.Horizontal = true;
            this.dControl.TargetControl = this.impostor;
            this.dControl.Vertical = true;
            // 
            // impostor
            // 
            this.impostor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.impostor.Controls.Add(this.InstaKillAll);
            this.impostor.Controls.Add(this.chkInstaKillAll);
            this.impostor.Controls.Add(this.bunifuCustomLabel10);
            this.impostor.Controls.Add(this.chkDoorCooldown);
            this.impostor.Controls.Add(this.bunifuCustomLabel11);
            this.impostor.Controls.Add(this.chkKillImpostor);
            this.impostor.Controls.Add(this.bunifuCustomLabel12);
            this.impostor.Controls.Add(this.bunifuCustomLabel13);
            this.impostor.Controls.Add(this.chkInfiniteSabotage);
            this.impostor.Controls.Add(this.chkIgnoreWalls);
            this.impostor.Controls.Add(this.bunifuCustomLabel9);
            this.impostor.Controls.Add(this.chkTaskImpostor);
            this.impostor.Controls.Add(this.bunifuCustomLabel8);
            this.impostor.Controls.Add(this.chkInfiniteRange);
            this.impostor.Controls.Add(this.bunifuCustomLabel7);
            this.impostor.Controls.Add(this.bunifuCustomLabel6);
            this.impostor.Controls.Add(this.chkKillCooldown);
            this.impostor.Controls.Add(this.chkImpostor);
            this.impostor.Controls.Add(this.bunifuCustomLabel1);
            this.impostor.Controls.Add(this.bunifuSeparator1);
            this.impostor.Location = new System.Drawing.Point(4, 25);
            this.impostor.Name = "impostor";
            this.impostor.Size = new System.Drawing.Size(540, 387);
            this.impostor.TabIndex = 0;
            this.impostor.Text = "Covid";
            this.impostor.Click += new System.EventHandler(this.impostor_Click);
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(301, 207);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(148, 24);
            this.bunifuCustomLabel10.TabIndex = 30;
            this.bunifuCustomLabel10.Text = "Door Cooldown";
            // 
            // chkDoorCooldown
            // 
            this.chkDoorCooldown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDoorCooldown.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDoorCooldown.Checked = false;
            this.chkDoorCooldown.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkDoorCooldown.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkDoorCooldown.ForeColor = System.Drawing.Color.White;
            this.chkDoorCooldown.Location = new System.Drawing.Point(281, 207);
            this.chkDoorCooldown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkDoorCooldown.Name = "chkDoorCooldown";
            this.chkDoorCooldown.Size = new System.Drawing.Size(20, 20);
            this.chkDoorCooldown.TabIndex = 29;
            this.chkDoorCooldown.OnChange += new System.EventHandler(this.chkDoorCooldown_OnChange);
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(301, 168);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(123, 24);
            this.bunifuCustomLabel11.TabIndex = 28;
            this.bunifuCustomLabel11.Text = "Kill Impostor";
            // 
            // chkKillImpostor
            // 
            this.chkKillImpostor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKillImpostor.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKillImpostor.Checked = false;
            this.chkKillImpostor.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkKillImpostor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkKillImpostor.ForeColor = System.Drawing.Color.White;
            this.chkKillImpostor.Location = new System.Drawing.Point(281, 168);
            this.chkKillImpostor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkKillImpostor.Name = "chkKillImpostor";
            this.chkKillImpostor.Size = new System.Drawing.Size(20, 20);
            this.chkKillImpostor.TabIndex = 27;
            this.chkKillImpostor.OnChange += new System.EventHandler(this.chkKillImpostor_OnChange);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(301, 129);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(165, 24);
            this.bunifuCustomLabel12.TabIndex = 26;
            this.bunifuCustomLabel12.Text = "Infinite Sabotage";
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(301, 90);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(124, 24);
            this.bunifuCustomLabel13.TabIndex = 25;
            this.bunifuCustomLabel13.Text = "Ignore Walls";
            // 
            // chkInfiniteSabotage
            // 
            this.chkInfiniteSabotage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteSabotage.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteSabotage.Checked = false;
            this.chkInfiniteSabotage.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkInfiniteSabotage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkInfiniteSabotage.ForeColor = System.Drawing.Color.White;
            this.chkInfiniteSabotage.Location = new System.Drawing.Point(281, 129);
            this.chkInfiniteSabotage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkInfiniteSabotage.Name = "chkInfiniteSabotage";
            this.chkInfiniteSabotage.Size = new System.Drawing.Size(20, 20);
            this.chkInfiniteSabotage.TabIndex = 24;
            this.chkInfiniteSabotage.OnChange += new System.EventHandler(this.chkInfiniteSabotage_OnChange);
            // 
            // chkIgnoreWalls
            // 
            this.chkIgnoreWalls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkIgnoreWalls.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkIgnoreWalls.Checked = false;
            this.chkIgnoreWalls.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkIgnoreWalls.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkIgnoreWalls.ForeColor = System.Drawing.Color.White;
            this.chkIgnoreWalls.Location = new System.Drawing.Point(281, 90);
            this.chkIgnoreWalls.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkIgnoreWalls.Name = "chkIgnoreWalls";
            this.chkIgnoreWalls.Size = new System.Drawing.Size(20, 20);
            this.chkIgnoreWalls.TabIndex = 23;
            this.chkIgnoreWalls.OnChange += new System.EventHandler(this.chkIgnoreWalls_OnChange);
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(41, 207);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(135, 24);
            this.bunifuCustomLabel9.TabIndex = 22;
            this.bunifuCustomLabel9.Text = "Task Impostor";
            // 
            // chkTaskImpostor
            // 
            this.chkTaskImpostor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkTaskImpostor.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkTaskImpostor.Checked = false;
            this.chkTaskImpostor.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkTaskImpostor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkTaskImpostor.ForeColor = System.Drawing.Color.White;
            this.chkTaskImpostor.Location = new System.Drawing.Point(21, 207);
            this.chkTaskImpostor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkTaskImpostor.Name = "chkTaskImpostor";
            this.chkTaskImpostor.Size = new System.Drawing.Size(20, 20);
            this.chkTaskImpostor.TabIndex = 21;
            this.chkTaskImpostor.OnChange += new System.EventHandler(this.chkTaskImpostor_OnChange);
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(41, 168);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(137, 24);
            this.bunifuCustomLabel8.TabIndex = 20;
            this.bunifuCustomLabel8.Text = "Infinite Range";
            // 
            // chkInfiniteRange
            // 
            this.chkInfiniteRange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteRange.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteRange.Checked = false;
            this.chkInfiniteRange.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkInfiniteRange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkInfiniteRange.ForeColor = System.Drawing.Color.White;
            this.chkInfiniteRange.Location = new System.Drawing.Point(21, 168);
            this.chkInfiniteRange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkInfiniteRange.Name = "chkInfiniteRange";
            this.chkInfiniteRange.Size = new System.Drawing.Size(20, 20);
            this.chkInfiniteRange.TabIndex = 19;
            this.chkInfiniteRange.OnChange += new System.EventHandler(this.chkInfiniteRange_OnChange);
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(41, 129);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(132, 24);
            this.bunifuCustomLabel7.TabIndex = 18;
            this.bunifuCustomLabel7.Text = "Kill Cooldown";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(41, 90);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(92, 24);
            this.bunifuCustomLabel6.TabIndex = 17;
            this.bunifuCustomLabel6.Text = "Impostor";
            // 
            // chkKillCooldown
            // 
            this.chkKillCooldown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKillCooldown.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKillCooldown.Checked = false;
            this.chkKillCooldown.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkKillCooldown.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkKillCooldown.ForeColor = System.Drawing.Color.White;
            this.chkKillCooldown.Location = new System.Drawing.Point(21, 129);
            this.chkKillCooldown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkKillCooldown.Name = "chkKillCooldown";
            this.chkKillCooldown.Size = new System.Drawing.Size(20, 20);
            this.chkKillCooldown.TabIndex = 16;
            this.chkKillCooldown.OnChange += new System.EventHandler(this.chkKillCooldown_OnChange);
            // 
            // chkImpostor
            // 
            this.chkImpostor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkImpostor.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkImpostor.Checked = false;
            this.chkImpostor.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkImpostor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkImpostor.ForeColor = System.Drawing.Color.White;
            this.chkImpostor.Location = new System.Drawing.Point(21, 90);
            this.chkImpostor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkImpostor.Name = "chkImpostor";
            this.chkImpostor.Size = new System.Drawing.Size(20, 20);
            this.chkImpostor.TabIndex = 15;
            this.chkImpostor.OnChange += new System.EventHandler(this.chkImpostor_OnChange);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Montserrat Alternates", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(17, 17);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(108, 27);
            this.bunifuCustomLabel1.TabIndex = 12;
            this.bunifuCustomLabel1.Text = "Impostor";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(21, 35);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(81, 10);
            this.bunifuSeparator1.TabIndex = 13;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.bunifuImageButton4);
            this.panel1.Controls.Add(this.bunifuImageButton3);
            this.panel1.Controls.Add(this.bunifuImageButton2);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(60, 391);
            this.panel1.TabIndex = 0;
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(36)))));
            this.bunifuImageButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton4.Image = global::Covid.Properties.Resources.help;
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(14, 343);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(32, 32);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton4.TabIndex = 4;
            this.bunifuImageButton4.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton4, "Help");
            this.bunifuImageButton4.Zoom = 18;
            this.bunifuImageButton4.Click += new System.EventHandler(this.bunifuImageButton4_Click);
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(36)))));
            this.bunifuImageButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton3.Image = global::Covid.Properties.Resources.automation_32px;
            this.bunifuImageButton3.ImageActive = global::Covid.Properties.Resources.miscellaneous;
            this.bunifuImageButton3.Location = new System.Drawing.Point(14, 129);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(32, 32);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 3;
            this.bunifuImageButton3.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton3, "Miscellaneous");
            this.bunifuImageButton3.Zoom = 18;
            this.bunifuImageButton3.Click += new System.EventHandler(this.bunifuImageButton3_Click);
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(36)))));
            this.bunifuImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton2.Image = global::Covid.Properties.Resources.eye_32px;
            this.bunifuImageButton2.ImageActive = global::Covid.Properties.Resources.vision;
            this.bunifuImageButton2.Location = new System.Drawing.Point(14, 72);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(32, 32);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 2;
            this.bunifuImageButton2.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton2, "Vision");
            this.bunifuImageButton2.Zoom = 18;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(26)))), ((int)(((byte)(36)))));
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Enabled = false;
            this.bunifuImageButton1.Image = global::Covid.Properties.Resources.impostor;
            this.bunifuImageButton1.ImageActive = global::Covid.Properties.Resources.knife_32px1;
            this.bunifuImageButton1.Location = new System.Drawing.Point(14, 15);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(32, 32);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1;
            this.bunifuImageButton1.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton1, "Impostor");
            this.bunifuImageButton1.Zoom = 18;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(3, 11);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(2, 40);
            this.panel3.TabIndex = 1;
            // 
            // tHint
            // 
            this.tHint.AutoPopDelay = 5000;
            this.tHint.InitialDelay = 100;
            this.tHint.ReshowDelay = 100;
            // 
            // bunifuImageButton7
            // 
            this.bunifuImageButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.bunifuImageButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton7.Image = global::Covid.Properties.Resources.info_24px;
            this.bunifuImageButton7.ImageActive = global::Covid.Properties.Resources.info_24px1;
            this.bunifuImageButton7.Location = new System.Drawing.Point(498, 17);
            this.bunifuImageButton7.Name = "bunifuImageButton7";
            this.bunifuImageButton7.Size = new System.Drawing.Size(24, 24);
            this.bunifuImageButton7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton7.TabIndex = 54;
            this.bunifuImageButton7.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton7, "Exit");
            this.bunifuImageButton7.Zoom = 0;
            this.bunifuImageButton7.Click += new System.EventHandler(this.bunifuImageButton7_Click_1);
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.bunifuImageButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton6.Image = global::Covid.Properties.Resources.subtract_24px;
            this.bunifuImageButton6.ImageActive = global::Covid.Properties.Resources.subtract_24px1;
            this.bunifuImageButton6.Location = new System.Drawing.Point(530, 17);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Size = new System.Drawing.Size(24, 24);
            this.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton6.TabIndex = 53;
            this.bunifuImageButton6.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton6, "Minimize");
            this.bunifuImageButton6.Zoom = 0;
            this.bunifuImageButton6.Click += new System.EventHandler(this.bunifuImageButton6_Click_1);
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.bunifuImageButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton5.Image = global::Covid.Properties.Resources.delete_24px;
            this.bunifuImageButton5.ImageActive = global::Covid.Properties.Resources.delete_24px1;
            this.bunifuImageButton5.Location = new System.Drawing.Point(562, 17);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Size = new System.Drawing.Size(24, 24);
            this.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton5.TabIndex = 52;
            this.bunifuImageButton5.TabStop = false;
            this.tHint.SetToolTip(this.bunifuImageButton5, "Exit");
            this.bunifuImageButton5.Zoom = 0;
            this.bunifuImageButton5.Click += new System.EventHandler(this.bunifuImageButton5_Click_1);
            // 
            // speedSlider
            // 
            this.speedSlider.BackColor = System.Drawing.Color.Transparent;
            this.speedSlider.BackgroudColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.speedSlider.BorderRadius = 3;
            this.speedSlider.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.speedSlider.Location = new System.Drawing.Point(20, 236);
            this.speedSlider.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.speedSlider.MaximumValue = 50;
            this.speedSlider.Name = "speedSlider";
            this.speedSlider.Size = new System.Drawing.Size(146, 35);
            this.speedSlider.TabIndex = 52;
            this.tHint.SetToolTip(this.speedSlider, "Movement Speed");
            this.speedSlider.Value = 0;
            this.speedSlider.ValueChanged += new System.EventHandler(this.bunifuSlider1_ValueChanged);
            // 
            // cForm
            // 
            this.cForm.Interval = 1;
            this.cForm.Tick += new System.EventHandler(this.cForm_Tick);
            // 
            // oForm
            // 
            this.oForm.Enabled = true;
            this.oForm.Interval = 1;
            this.oForm.Tick += new System.EventHandler(this.oForm_Tick);
            // 
            // dControl2
            // 
            this.dControl2.Fixed = true;
            this.dControl2.Horizontal = true;
            this.dControl2.TargetControl = this.panel1;
            this.dControl2.Vertical = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.impostor);
            this.tabControl1.Controls.Add(this.vision);
            this.tabControl1.Controls.Add(this.miscellaneous);
            this.tabControl1.Location = new System.Drawing.Point(56, -22);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(548, 416);
            this.tabControl1.TabIndex = 0;
            // 
            // vision
            // 
            this.vision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.vision.Controls.Add(this.bunifuCustomLabel25);
            this.vision.Controls.Add(this.chkSeeGhostsChat);
            this.vision.Controls.Add(this.bunifuCustomLabel14);
            this.vision.Controls.Add(this.chkSeeGhosts);
            this.vision.Controls.Add(this.bunifuCustomLabel15);
            this.vision.Controls.Add(this.bunifuCustomLabel16);
            this.vision.Controls.Add(this.chkSuperVision);
            this.vision.Controls.Add(this.chkSeeImpostor);
            this.vision.Controls.Add(this.bunifuCustomLabel3);
            this.vision.Controls.Add(this.bunifuCustomLabel2);
            this.vision.Controls.Add(this.bunifuSeparator2);
            this.vision.Location = new System.Drawing.Point(4, 25);
            this.vision.Name = "vision";
            this.vision.Size = new System.Drawing.Size(540, 387);
            this.vision.TabIndex = 0;
            this.vision.Text = "tabPage2";
            // 
            // bunifuCustomLabel25
            // 
            this.bunifuCustomLabel25.AutoSize = true;
            this.bunifuCustomLabel25.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel25.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel25.Location = new System.Drawing.Point(41, 207);
            this.bunifuCustomLabel25.Name = "bunifuCustomLabel25";
            this.bunifuCustomLabel25.Size = new System.Drawing.Size(150, 24);
            this.bunifuCustomLabel25.TabIndex = 52;
            this.bunifuCustomLabel25.Text = "See Ghosts Chat";
            // 
            // chkSeeGhostsChat
            // 
            this.chkSeeGhostsChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeGhostsChat.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeGhostsChat.Checked = false;
            this.chkSeeGhostsChat.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkSeeGhostsChat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkSeeGhostsChat.ForeColor = System.Drawing.Color.White;
            this.chkSeeGhostsChat.Location = new System.Drawing.Point(21, 207);
            this.chkSeeGhostsChat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkSeeGhostsChat.Name = "chkSeeGhostsChat";
            this.chkSeeGhostsChat.Size = new System.Drawing.Size(20, 20);
            this.chkSeeGhostsChat.TabIndex = 51;
            this.chkSeeGhostsChat.OnChange += new System.EventHandler(this.chkSeeGhostsChat_OnChange);
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(41, 168);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(103, 24);
            this.bunifuCustomLabel14.TabIndex = 28;
            this.bunifuCustomLabel14.Text = "See Ghosts";
            // 
            // chkSeeGhosts
            // 
            this.chkSeeGhosts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeGhosts.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeGhosts.Checked = false;
            this.chkSeeGhosts.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkSeeGhosts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkSeeGhosts.ForeColor = System.Drawing.Color.White;
            this.chkSeeGhosts.Location = new System.Drawing.Point(21, 168);
            this.chkSeeGhosts.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkSeeGhosts.Name = "chkSeeGhosts";
            this.chkSeeGhosts.Size = new System.Drawing.Size(20, 20);
            this.chkSeeGhosts.TabIndex = 27;
            this.chkSeeGhosts.OnChange += new System.EventHandler(this.chkSeeGhosts_OnChange);
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(41, 129);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(117, 24);
            this.bunifuCustomLabel15.TabIndex = 26;
            this.bunifuCustomLabel15.Text = "Super Vision";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel16.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(41, 90);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(126, 24);
            this.bunifuCustomLabel16.TabIndex = 25;
            this.bunifuCustomLabel16.Text = "See Impostor";
            // 
            // chkSuperVision
            // 
            this.chkSuperVision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSuperVision.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSuperVision.Checked = false;
            this.chkSuperVision.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkSuperVision.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkSuperVision.ForeColor = System.Drawing.Color.White;
            this.chkSuperVision.Location = new System.Drawing.Point(21, 129);
            this.chkSuperVision.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkSuperVision.Name = "chkSuperVision";
            this.chkSuperVision.Size = new System.Drawing.Size(20, 20);
            this.chkSuperVision.TabIndex = 24;
            this.chkSuperVision.OnChange += new System.EventHandler(this.chkSuperVision_OnChange);
            // 
            // chkSeeImpostor
            // 
            this.chkSeeImpostor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeImpostor.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSeeImpostor.Checked = false;
            this.chkSeeImpostor.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkSeeImpostor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkSeeImpostor.ForeColor = System.Drawing.Color.White;
            this.chkSeeImpostor.Location = new System.Drawing.Point(21, 90);
            this.chkSeeImpostor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkSeeImpostor.Name = "chkSeeImpostor";
            this.chkSeeImpostor.Size = new System.Drawing.Size(20, 20);
            this.chkSeeImpostor.TabIndex = 23;
            this.chkSeeImpostor.OnChange += new System.EventHandler(this.chkSeeImpostor_OnChange);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Montserrat Alternates", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(17, 17);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(73, 27);
            this.bunifuCustomLabel3.TabIndex = 14;
            this.bunifuCustomLabel3.Text = "Vision";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Montserrat Alternates", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(17, 17);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(73, 27);
            this.bunifuCustomLabel2.TabIndex = 14;
            this.bunifuCustomLabel2.Text = "Vision";
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(21, 35);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(54, 10);
            this.bunifuSeparator2.TabIndex = 15;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // miscellaneous
            // 
            this.miscellaneous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel28);
            this.miscellaneous.Controls.Add(this.chkSkipAll);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel27);
            this.miscellaneous.Controls.Add(this.chkNukeRoom);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel26);
            this.miscellaneous.Controls.Add(this.speedSlider);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel24);
            this.miscellaneous.Controls.Add(this.chkInfiniteKickVote);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel5);
            this.miscellaneous.Controls.Add(this.chkBypassBanRooms);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel17);
            this.miscellaneous.Controls.Add(this.chkUnlockItems);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel18);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel19);
            this.miscellaneous.Controls.Add(this.chkWallhack);
            this.miscellaneous.Controls.Add(this.chkRemoveBanTime);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel20);
            this.miscellaneous.Controls.Add(this.chkDoubleHost);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel21);
            this.miscellaneous.Controls.Add(this.chkFastChat);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel22);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel23);
            this.miscellaneous.Controls.Add(this.chkLagSwitch);
            this.miscellaneous.Controls.Add(this.chkKickAll);
            this.miscellaneous.Controls.Add(this.bunifuCustomLabel4);
            this.miscellaneous.Controls.Add(this.bunifuSeparator3);
            this.miscellaneous.Location = new System.Drawing.Point(4, 25);
            this.miscellaneous.Name = "miscellaneous";
            this.miscellaneous.Size = new System.Drawing.Size(540, 387);
            this.miscellaneous.TabIndex = 1;
            this.miscellaneous.Text = "tabPage1";
            this.miscellaneous.Click += new System.EventHandler(this.miscellaneous_Click);
            // 
            // bunifuCustomLabel28
            // 
            this.bunifuCustomLabel28.AutoSize = true;
            this.bunifuCustomLabel28.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel28.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel28.Location = new System.Drawing.Point(301, 244);
            this.bunifuCustomLabel28.Name = "bunifuCustomLabel28";
            this.bunifuCustomLabel28.Size = new System.Drawing.Size(71, 24);
            this.bunifuCustomLabel28.TabIndex = 57;
            this.bunifuCustomLabel28.Text = "SkipAll";
            // 
            // chkSkipAll
            // 
            this.chkSkipAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSkipAll.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkSkipAll.Checked = false;
            this.chkSkipAll.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkSkipAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkSkipAll.ForeColor = System.Drawing.Color.White;
            this.chkSkipAll.Location = new System.Drawing.Point(281, 244);
            this.chkSkipAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkSkipAll.Name = "chkSkipAll";
            this.chkSkipAll.Size = new System.Drawing.Size(20, 20);
            this.chkSkipAll.TabIndex = 56;
            this.chkSkipAll.OnChange += new System.EventHandler(this.chkSkipAll_OnChange);
            // 
            // bunifuCustomLabel27
            // 
            this.bunifuCustomLabel27.AutoSize = true;
            this.bunifuCustomLabel27.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel27.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel27.Location = new System.Drawing.Point(301, 207);
            this.bunifuCustomLabel27.Name = "bunifuCustomLabel27";
            this.bunifuCustomLabel27.Size = new System.Drawing.Size(111, 24);
            this.bunifuCustomLabel27.TabIndex = 55;
            this.bunifuCustomLabel27.Text = "Nuke Room";
            // 
            // chkNukeRoom
            // 
            this.chkNukeRoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkNukeRoom.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkNukeRoom.Checked = false;
            this.chkNukeRoom.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkNukeRoom.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkNukeRoom.ForeColor = System.Drawing.Color.White;
            this.chkNukeRoom.Location = new System.Drawing.Point(281, 207);
            this.chkNukeRoom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkNukeRoom.Name = "chkNukeRoom";
            this.chkNukeRoom.Size = new System.Drawing.Size(20, 20);
            this.chkNukeRoom.TabIndex = 54;
            this.chkNukeRoom.OnChange += new System.EventHandler(this.chkNukeRoom_OnChange);
            // 
            // bunifuCustomLabel26
            // 
            this.bunifuCustomLabel26.AutoSize = true;
            this.bunifuCustomLabel26.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel26.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel26.Location = new System.Drawing.Point(179, 240);
            this.bunifuCustomLabel26.Name = "bunifuCustomLabel26";
            this.bunifuCustomLabel26.Size = new System.Drawing.Size(21, 24);
            this.bunifuCustomLabel26.TabIndex = 53;
            this.bunifuCustomLabel26.Text = "0";
            // 
            // bunifuCustomLabel24
            // 
            this.bunifuCustomLabel24.AutoSize = true;
            this.bunifuCustomLabel24.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel24.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel24.Location = new System.Drawing.Point(40, 203);
            this.bunifuCustomLabel24.Name = "bunifuCustomLabel24";
            this.bunifuCustomLabel24.Size = new System.Drawing.Size(159, 24);
            this.bunifuCustomLabel24.TabIndex = 48;
            this.bunifuCustomLabel24.Text = "Infinite Kick Vote";
            // 
            // chkInfiniteKickVote
            // 
            this.chkInfiniteKickVote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteKickVote.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInfiniteKickVote.Checked = false;
            this.chkInfiniteKickVote.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkInfiniteKickVote.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkInfiniteKickVote.ForeColor = System.Drawing.Color.White;
            this.chkInfiniteKickVote.Location = new System.Drawing.Point(20, 203);
            this.chkInfiniteKickVote.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkInfiniteKickVote.Name = "chkInfiniteKickVote";
            this.chkInfiniteKickVote.Size = new System.Drawing.Size(20, 20);
            this.chkInfiniteKickVote.TabIndex = 47;
            this.chkInfiniteKickVote.OnChange += new System.EventHandler(this.chkInfiniteKickVote_OnChange);
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(9, 355);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(142, 24);
            this.bunifuCustomLabel5.TabIndex = 46;
            this.bunifuCustomLabel5.Text = "Invisible Name\r\n";
            this.bunifuCustomLabel5.Visible = false;
            // 
            // chkBypassBanRooms
            // 
            this.chkBypassBanRooms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkBypassBanRooms.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkBypassBanRooms.Checked = false;
            this.chkBypassBanRooms.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkBypassBanRooms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkBypassBanRooms.Enabled = false;
            this.chkBypassBanRooms.ForeColor = System.Drawing.Color.White;
            this.chkBypassBanRooms.Location = new System.Drawing.Point(13, 359);
            this.chkBypassBanRooms.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkBypassBanRooms.Name = "chkBypassBanRooms";
            this.chkBypassBanRooms.Size = new System.Drawing.Size(20, 20);
            this.chkBypassBanRooms.TabIndex = 45;
            this.chkBypassBanRooms.Visible = false;
            this.chkBypassBanRooms.OnChange += new System.EventHandler(this.chkBypassBanRooms_OnChange);
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(301, 168);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(127, 24);
            this.bunifuCustomLabel17.TabIndex = 44;
            this.bunifuCustomLabel17.Text = "Unlock Items";
            // 
            // chkUnlockItems
            // 
            this.chkUnlockItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkUnlockItems.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkUnlockItems.Checked = false;
            this.chkUnlockItems.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkUnlockItems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkUnlockItems.ForeColor = System.Drawing.Color.White;
            this.chkUnlockItems.Location = new System.Drawing.Point(281, 168);
            this.chkUnlockItems.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkUnlockItems.Name = "chkUnlockItems";
            this.chkUnlockItems.Size = new System.Drawing.Size(20, 20);
            this.chkUnlockItems.TabIndex = 43;
            this.chkUnlockItems.OnChange += new System.EventHandler(this.chkUnlockItems_OnChange);
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(301, 129);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(96, 24);
            this.bunifuCustomLabel18.TabIndex = 42;
            this.bunifuCustomLabel18.Text = "Wallhack";
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel19.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(301, 90);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(168, 24);
            this.bunifuCustomLabel19.TabIndex = 41;
            this.bunifuCustomLabel19.Text = "Remove Ban Time";
            // 
            // chkWallhack
            // 
            this.chkWallhack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkWallhack.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkWallhack.Checked = false;
            this.chkWallhack.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkWallhack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkWallhack.ForeColor = System.Drawing.Color.White;
            this.chkWallhack.Location = new System.Drawing.Point(281, 129);
            this.chkWallhack.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkWallhack.Name = "chkWallhack";
            this.chkWallhack.Size = new System.Drawing.Size(20, 20);
            this.chkWallhack.TabIndex = 40;
            this.chkWallhack.OnChange += new System.EventHandler(this.chkWallhack_OnChange);
            // 
            // chkRemoveBanTime
            // 
            this.chkRemoveBanTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkRemoveBanTime.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkRemoveBanTime.Checked = false;
            this.chkRemoveBanTime.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkRemoveBanTime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkRemoveBanTime.ForeColor = System.Drawing.Color.White;
            this.chkRemoveBanTime.Location = new System.Drawing.Point(281, 90);
            this.chkRemoveBanTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkRemoveBanTime.Name = "chkRemoveBanTime";
            this.chkRemoveBanTime.Size = new System.Drawing.Size(20, 20);
            this.chkRemoveBanTime.TabIndex = 39;
            this.chkRemoveBanTime.OnChange += new System.EventHandler(this.chkRemoveBanTime_OnChange);
            // 
            // bunifuCustomLabel20
            // 
            this.bunifuCustomLabel20.AutoSize = true;
            this.bunifuCustomLabel20.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel20.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel20.Location = new System.Drawing.Point(40, 164);
            this.bunifuCustomLabel20.Name = "bunifuCustomLabel20";
            this.bunifuCustomLabel20.Size = new System.Drawing.Size(117, 24);
            this.bunifuCustomLabel20.TabIndex = 38;
            this.bunifuCustomLabel20.Text = "Double Host";
            // 
            // chkDoubleHost
            // 
            this.chkDoubleHost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDoubleHost.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkDoubleHost.Checked = false;
            this.chkDoubleHost.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkDoubleHost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkDoubleHost.ForeColor = System.Drawing.Color.White;
            this.chkDoubleHost.Location = new System.Drawing.Point(20, 164);
            this.chkDoubleHost.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkDoubleHost.Name = "chkDoubleHost";
            this.chkDoubleHost.Size = new System.Drawing.Size(20, 20);
            this.chkDoubleHost.TabIndex = 37;
            this.chkDoubleHost.OnChange += new System.EventHandler(this.chkDoubleHost_OnChange);
            // 
            // bunifuCustomLabel21
            // 
            this.bunifuCustomLabel21.AutoSize = true;
            this.bunifuCustomLabel21.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel21.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel21.Location = new System.Drawing.Point(40, 125);
            this.bunifuCustomLabel21.Name = "bunifuCustomLabel21";
            this.bunifuCustomLabel21.Size = new System.Drawing.Size(93, 24);
            this.bunifuCustomLabel21.TabIndex = 36;
            this.bunifuCustomLabel21.Text = "Fast Chat";
            // 
            // chkFastChat
            // 
            this.chkFastChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkFastChat.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkFastChat.Checked = false;
            this.chkFastChat.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkFastChat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkFastChat.ForeColor = System.Drawing.Color.White;
            this.chkFastChat.Location = new System.Drawing.Point(20, 125);
            this.chkFastChat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkFastChat.Name = "chkFastChat";
            this.chkFastChat.Size = new System.Drawing.Size(20, 20);
            this.chkFastChat.TabIndex = 35;
            this.chkFastChat.OnChange += new System.EventHandler(this.chkFastChat_OnChange);
            // 
            // bunifuCustomLabel22
            // 
            this.bunifuCustomLabel22.AutoSize = true;
            this.bunifuCustomLabel22.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel22.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel22.Location = new System.Drawing.Point(40, 86);
            this.bunifuCustomLabel22.Name = "bunifuCustomLabel22";
            this.bunifuCustomLabel22.Size = new System.Drawing.Size(109, 24);
            this.bunifuCustomLabel22.TabIndex = 34;
            this.bunifuCustomLabel22.Text = "Lag Switch";
            // 
            // bunifuCustomLabel23
            // 
            this.bunifuCustomLabel23.AutoSize = true;
            this.bunifuCustomLabel23.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel23.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel23.Location = new System.Drawing.Point(9, 355);
            this.bunifuCustomLabel23.Name = "bunifuCustomLabel23";
            this.bunifuCustomLabel23.Size = new System.Drawing.Size(191, 24);
            this.bunifuCustomLabel23.TabIndex = 33;
            this.bunifuCustomLabel23.Text = "Set All Names Hacke";
            this.bunifuCustomLabel23.Visible = false;
            // 
            // chkLagSwitch
            // 
            this.chkLagSwitch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkLagSwitch.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkLagSwitch.Checked = false;
            this.chkLagSwitch.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkLagSwitch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkLagSwitch.ForeColor = System.Drawing.Color.White;
            this.chkLagSwitch.Location = new System.Drawing.Point(20, 86);
            this.chkLagSwitch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkLagSwitch.Name = "chkLagSwitch";
            this.chkLagSwitch.Size = new System.Drawing.Size(20, 20);
            this.chkLagSwitch.TabIndex = 32;
            this.chkLagSwitch.OnChange += new System.EventHandler(this.chkLagSwitch_OnChange);
            // 
            // chkKickAll
            // 
            this.chkKickAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKickAll.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkKickAll.Checked = false;
            this.chkKickAll.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkKickAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkKickAll.Enabled = false;
            this.chkKickAll.ForeColor = System.Drawing.Color.White;
            this.chkKickAll.Location = new System.Drawing.Point(13, 359);
            this.chkKickAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkKickAll.Name = "chkKickAll";
            this.chkKickAll.Size = new System.Drawing.Size(20, 20);
            this.chkKickAll.TabIndex = 31;
            this.chkKickAll.Visible = false;
            this.chkKickAll.OnChange += new System.EventHandler(this.chkKickAll_OnChange);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Montserrat Alternates", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(17, 17);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(163, 27);
            this.bunifuCustomLabel4.TabIndex = 16;
            this.bunifuCustomLabel4.Text = "Miscellaneous";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(21, 35);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(128, 10);
            this.bunifuSeparator3.TabIndex = 17;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.vision;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.miscellaneous;
            this.bunifuDragControl2.Vertical = true;
            // 
            // Injection
            // 
            this.Injection.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Injection_DoWork);
            // 
            // Votes
            // 
            this.Votes.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Votes_DoWork);
            // 
            // notifControl1
            // 
            this.notifControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(28)))), ((int)(((byte)(38)))));
            this.notifControl1.Location = new System.Drawing.Point(365, 315);
            this.notifControl1.Name = "notifControl1";
            this.notifControl1.Size = new System.Drawing.Size(233, 73);
            this.notifControl1.TabIndex = 51;
            this.notifControl1.Load += new System.EventHandler(this.notifControl1_Load);
            // 
            // InstaKillAll
            // 
            this.InstaKillAll.AutoSize = true;
            this.InstaKillAll.Font = new System.Drawing.Font("Montserrat Alternates", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InstaKillAll.ForeColor = System.Drawing.Color.White;
            this.InstaKillAll.Location = new System.Drawing.Point(41, 243);
            this.InstaKillAll.Name = "InstaKillAll";
            this.InstaKillAll.Size = new System.Drawing.Size(108, 24);
            this.InstaKillAll.TabIndex = 61;
            this.InstaKillAll.Text = "InstaKillAll";
            // 
            // chkInstaKillAll
            // 
            this.chkInstaKillAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInstaKillAll.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.chkInstaKillAll.Checked = false;
            this.chkInstaKillAll.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(25)))), ((int)(((byte)(80)))));
            this.chkInstaKillAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkInstaKillAll.ForeColor = System.Drawing.Color.White;
            this.chkInstaKillAll.Location = new System.Drawing.Point(21, 243);
            this.chkInstaKillAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkInstaKillAll.Name = "chkInstaKillAll";
            this.chkInstaKillAll.Size = new System.Drawing.Size(20, 20);
            this.chkInstaKillAll.TabIndex = 60;
            this.chkInstaKillAll.OnChange += new System.EventHandler(this.chkInstaKillAll_OnChange);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(22)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(601, 391);
            this.Controls.Add(this.bunifuImageButton7);
            this.Controls.Add(this.bunifuImageButton6);
            this.Controls.Add(this.bunifuImageButton5);
            this.Controls.Add(this.notifControl1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Covid";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.impostor.ResumeLayout(false);
            this.impostor.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.vision.ResumeLayout(false);
            this.vision.PerformLayout();
            this.miscellaneous.ResumeLayout(false);
            this.miscellaneous.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse fElipse;
        private Bunifu.Framework.UI.BunifuDragControl dControl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private System.Windows.Forms.ToolTip tHint;
        private System.Windows.Forms.Timer oForm;
        private Bunifu.Framework.UI.BunifuDragControl dControl2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage impostor;
        private System.Windows.Forms.TabPage vision;
        private System.Windows.Forms.TabPage miscellaneous;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private Bunifu.Framework.UI.BunifuCheckbox chkImpostor;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCheckbox chkDoorCooldown;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCheckbox chkKillImpostor;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuCheckbox chkInfiniteSabotage;
        private Bunifu.Framework.UI.BunifuCheckbox chkIgnoreWalls;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCheckbox chkTaskImpostor;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCheckbox chkInfiniteRange;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCheckbox chkKillCooldown;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private Bunifu.Framework.UI.BunifuCheckbox chkSeeGhosts;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private Bunifu.Framework.UI.BunifuCheckbox chkSuperVision;
        private Bunifu.Framework.UI.BunifuCheckbox chkSeeImpostor;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel24;
        private Bunifu.Framework.UI.BunifuCheckbox chkInfiniteKickVote;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCheckbox chkBypassBanRooms;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private Bunifu.Framework.UI.BunifuCheckbox chkUnlockItems;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel19;
        private Bunifu.Framework.UI.BunifuCheckbox chkWallhack;
        private Bunifu.Framework.UI.BunifuCheckbox chkRemoveBanTime;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel20;
        private Bunifu.Framework.UI.BunifuCheckbox chkDoubleHost;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel21;
        private Bunifu.Framework.UI.BunifuCheckbox chkFastChat;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel22;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel23;
        private Bunifu.Framework.UI.BunifuCheckbox chkLagSwitch;
        private Bunifu.Framework.UI.BunifuCheckbox chkKickAll;
        private NotifControl notifControl1;
        private Bunifu.Framework.UI.BunifuSlider speedSlider;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel26;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton7;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton6;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton5;
        private System.ComponentModel.BackgroundWorker Injection;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel25;
        private Bunifu.Framework.UI.BunifuCheckbox chkSeeGhostsChat;
        private System.ComponentModel.BackgroundWorker Votes;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel27;
        private Bunifu.Framework.UI.BunifuCheckbox chkNukeRoom;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel28;
        private Bunifu.Framework.UI.BunifuCheckbox chkSkipAll;
        private System.Windows.Forms.Timer cForm;
        private Bunifu.Framework.UI.BunifuCustomLabel InstaKillAll;
        private Bunifu.Framework.UI.BunifuCheckbox chkInstaKillAll;
    }
}

