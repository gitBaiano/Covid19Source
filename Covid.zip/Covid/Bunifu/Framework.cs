﻿namespace Bunifu
{
    internal class Framework
    {
    }
}